# Parcial AREP - Primer corte

1. Construir una  aplicación web usando sockets que reciba un operación  matemática y una lista de parámetros separados por coma y retorne el valor correspondiente. El comando puede ser cualquiera de la libería clase Math de java o el comando "qck". La aplicación asume que los números que recibe siempre son de tipo Double. El comando se debe invocar usando reflexión. Si la calculadora recibe el comando es "qck" los parámetros serán una a lista de números desordenada y los retorna de manera ordenada usando quicksort.
2. Arquitectura:
- La aplicación tendrá tres componentes distribuidos: Una fachada de servicios, un servicio de calculadora, y un cliente web (html +js).
- Los servicios de la fachada y de la calculadora deben estar desplegados en máquinas virtuales  diferentes.


## corriendo

## Autor
