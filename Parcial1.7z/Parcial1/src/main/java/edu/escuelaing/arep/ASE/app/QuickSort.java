package edu.escuelaing.arep.ASE.app;

import java.util.ArrayList;
import java.util.DuplicateFormatFlagsException;

public class QuickSort {
    int inicio = 0;
    int fin = 0;
    Double[] izquierda;
    Double[] derecha;



    public int particion (Double[] lista){
        int p = 0;
        if (lista.length%2==0) {
            p = lista.length /2;            
        } else{
            p = (lista.length / 2) +1;
        }
        return p;
    }

    public Double[] ordenarGeneral (Double[] ordenados){
        Double[] aux;
        if (izquierda[-1]< derecha[0]) {            
            
        }
        return aux;
    }

    public Double[] ordenarIzqu(Double[] lista){
        

    }
    
    public Double[] ordenarDer(Double[] lista){

    }
}
