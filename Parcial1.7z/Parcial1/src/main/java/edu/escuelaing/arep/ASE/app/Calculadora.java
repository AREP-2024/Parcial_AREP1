package edu.escuelaing.arep.ASE.app;

public class Calculadora {

    public Double operacionesMath (String operacion, Double num1){
        Double resul = 0.0;
        if (operacion.equals("tan")) {
            resul = Math.tan(num1);
            
        } else if (operacion.equals("cos")) {
            resul = Math.cos(num1);
            
        }else if (operacion.equals("sin")){
            resul = Math.sin(num1);
        }else if (operacion.equals("abs")){
            resul = Math.abs(num1);
        }
        return resul;

    }

    
 
    
}
